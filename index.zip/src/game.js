let player, level, pl, gls, grl;
let debugMode = false;

function loadLevel(levelName) {
	if (level) {
		level.exit?.destroy();
		for (const l of level.levers ?? []) l.destroy();
		for (const m of level.masks ?? []) m.destroy();
		player?.destroy();
		for (const color of MASKS.slice(1)) {
			gls[color]?.destroy();
		}
		pl?.destroy();
	}

	const loadedLevel = levels.find((l) => l.name === levelName);
	if (!loadedLevel || debugMode) console.warn(`Level "${levelName}" not found`);
	level = { ...loadedLevel };

	player = new Player(
		level.startPos,
		vec2(0.5, 0.25),
		tile(vec2(), vec2(19, 21), 1),
	);

	level.exit = new Exit(level.exitPos);
	level.levers = level.leversData.map((d) => new Lever(d.pos, d.value));
	level.masks = level.masksData.map((d) => new Mask(d.pos, d.value));

	gasLayers = MASKS.slice(1);
	for (const color of gasLayers) {
		const data = level.gases
			.filter((g) => g.value.color === color)
			.reduce(
				(grid, gas) =>
					addToGrid(grid, gas.x + 16, gas.y + 16, gas.value, "gas"),
				createEmptyGrid(),
			);
		gasLayers[color] = createTileLayer(data, false, -9999);
	}

	pl = createTileLayer(
		level.pipes.reduce(
			(acc, pipe) =>
				addToGrid(acc, pipe.x + 16, pipe.y + 16, pipe.value, "pipe"),
			createEmptyGrid(),
		),
		true,
		-10000,
	);

	gls = gasLayers;
	grl = groundLayer();

	createPauseButton();

	return level;
}

function gameInit() {
	objectDefaultDamping = 0.7;
	setCanvasFixedSize(vec2(512, 512));
	canvasClearColor = color.grey;
	touchGamepadEnable = true;
	touchGamepadAnalog = false;
	touchGamepadButtonCount = 1;
	setFontDefault("Baskar Stc");

	createMainMenu();
}

function gameUpdate() {
	if (keyWasPressed("F1")) debugMode = !debugMode;

	if (keyWasPressed("Escape")) {
		if (gameState === "playing") {
			pauseGame();
			return;
		}
		if (gameState === "paused") {
			uiSystem.destroyObjects();
			gameState = "playing";
			return;
		}
	}

	if (gameState !== "playing") return;

	cameraScale = debugMode ? 12 : 32;
	debugOverlay = false;

	pipeTileAnimation();
	gasTileAnimation();

	MASKS.slice(1).forEach((color) => {
		const lever = level.levers.find((l) => l.name === color);
		const isOn = lever?.on ?? true;
		gls[color].pos = vec2(-16).add(isOn ? vec2(0) : vec2(1000));
		gls[color].redraw();
	});
}

const pipeTileAnimation = () => {
	const pipeGrid = level.pipes.reduce(
		(acc, pipe) => addToGrid(acc, pipe.x + 16, pipe.y + 16, pipe.value, "pipe"),
		createEmptyGrid(),
	);

	const tiles = Array.from({ length: 32 }, (_, y) =>
		Array.from({ length: 32 }, (_, x) => [x, y]),
	).flat();

	const brokenPipes = tiles
		.map(([x, y]) => ({
			pos: vec2(x, y),
			p: PIPE_BROKEN_LOOKUP[pipeGrid[y]?.[x]],
		}))
		.filter(({ p }) => p);

	for (const { pos, p } of brokenPipes) {
		const lever = level.levers.find((l) => l.name === p.color);
		const color = (lever?.on ?? true) ? p.color : "none";
		const frame = color === "none" || (time | 0) % 2 === 0 ? 0 : 36;
		pl.setData(pos, getTileData(pipe("broken", p.dir, color) + frame));
	}

	pl.redraw();
};

const gasTileAnimation = () => {
	const frame = ((time * 6) | 0) % 4;
	const gasFrame = frame === 3 ? 1 : frame;

	MASKS.slice(1).forEach((color) => {
		const layer = gls[color];
		const gasData = level.gases
			.filter((g) => g.value.color === color)
			.map((g) => ({
				pos: vec2(g.x + 16, g.y + 16),
				gas: g.value,
			}));

		gasData.forEach(({ pos, gas }) => {
			const tileIndex = typeof gas === "object" ? gas.tile : gas;
			layer.setData(pos, getTileData(tileIndex + gasFrame * 3));
		});
	});
};

function gameRender() {}

function postGameRender() {
	drawRect(vec2(0, -15.7), vec2(32, 1), color.grey); // hide pipelayer behind wall
	if (!player) return;
	const deathFade = 1 - player.health / 100;
	if (deathFade > 0)
		drawRect(vec2(), vec2(100), new Color(0, 0, 0, deathFade * 0.5));

	if (!debugMode) return;
	const currentTilePos = player.pos.floor().add(vec2(16));
	for (const color of MASKS.slice(1)) {
		const tileData = gls[color].getData(currentTilePos);
		if (tileData?.tile) {
			const tileNum = tileData.tile;
			drawTextScreen(
				`Tile: ${tileNum}`,
				vec2(80, 30),
				20,
				new Color(0, 0, 0, 1),
			);
			break;
		}
	}
	drawTextScreen(
		`Pos: ${Math.floor(player.pos.x)}, ${Math.floor(player.pos.y)}`,
		vec2(80, 55),
		16,
		new Color(0, 0, 0, 1),
	);
	drawTextScreen(
		`In Gas: ${player.inGas}`,
		vec2(80, 80),
		16,
		new Color(0, 0, 0, 1),
	);
	drawTextScreen(
		`Mask: ${player.maskColor}`,
		vec2(80, 105),
		16,
		new Color(0, 0, 0, 1),
	);
	const lever = level.levers.find((l) => l.name === player.inGas);
	drawTextScreen(
		`Lever: ${lever?.on ?? "none"}`,
		vec2(80, 130),
		16,
		new Color(0, 0, 0, 1),
	);
}

function pauseGame() {
	gameState = "paused";
	uiSystem.destroyObjects();
	createPauseMenu();
}

function createPauseButton() {
	const btn = makeButton(
		vec2(-225, 225),
		vec2(55, 30),
		"MENU",
		new Color(0, 0, 0, 0.5),
		new Color(0, 0, 0, 0.8),
		pauseGame,
	);
	btn.textHeight = 14;
}

function createPauseMenu() {
	const bg = new UIObject(vec2(), vec2());
	bg.color = new Color(0, 0, 0, 0.7);
	bg.gradientColor = undefined;
	bg.lineWidth = 0;
	bg.shadowColor = new Color(0, 0, 0, 0);
	bg.canBeHover = false;
	bg.isMouseOverlapping = () => true;
	bg.onRender = function () {
		const c = uiSystem.screenToNative(mainCanvasSize.scale(0.5));
		uiSystem.drawRect(c, vec2(512, 512), this.color, 0, BLACK, 0);
	};

	makeText(vec2(0, -100), vec2(400, 80), "PAUSED", color.red, 80);

	const resumeBtn = makeButton(
		vec2(0, 0),
		vec2(300, 60),
		"RESUME",
		CLEAR_BLACK,
		CLEAR_BLACK,
		() => {
			setTimeout(() => {
				uiSystem.destroyObjects();
				gameState = "playing";
			});
		},
	);
	resumeBtn.textColor = color.red;
	resumeBtn.lineColor = color.red;
	resumeBtn.onEnter = function () {
		this.textColor = BLACK;
		this.lineColor = BLACK;
	};
	resumeBtn.onLeave = function () {
		this.textColor = color.red;
		this.lineColor = color.red;
	};

	const quitBtn = makeButton(
		vec2(0, 80),
		vec2(300, 60),
		"QUIT",
		CLEAR_BLACK,
		CLEAR_BLACK,
		() => {
			setTimeout(() => {
				uiSystem.destroyObjects();
				returnToLevelSelect();
			});
		},
	);
	quitBtn.textColor = color.red;
	quitBtn.lineColor = color.red;
	quitBtn.onEnter = function () {
		this.textColor = BLACK;
		this.lineColor = BLACK;
	};
	quitBtn.onLeave = function () {
		this.textColor = color.red;
		this.lineColor = color.red;
	};
}

engineInit(gameInit, gameUpdate, null, gameRender, postGameRender, [
	"assets/tiles.png",
	"assets/gorm.png",
	"assets/masks.png",
	"assets/concrete.jpg",
]);
