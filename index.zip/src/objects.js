class GameObject extends EngineObject {
	update() {
		this.renderOrder = -this.pos.y; // sort by y position
	}
	render() {
		const drawSize = this.drawSize || this.size;
		const offset = this.getUp(drawSize.y / 4);
		const pos = this.pos.add(offset);
		drawTile(pos, drawSize, this.tileInfo, undefined, undefined, this.mirror);
	}
}

class Lever extends GameObject {
	constructor(pos, name) {
		super(pos, vec2(0.5), tile(vec2(10, 10), vec2(16), 0));
		this.on = true;
		this.name = name;
	}
	toggle() {
		this.on = !this.on;
		this.tileInfo = tile(vec2(9, 10), vec2(16)).frame(this.on ? 1 : 0);
		sfx.lever.play(this.pos, 0.66);
	}
}

class Mask extends GameObject {
	constructor(pos, name) {
		super(pos, vec2(0.5), tile(vec2(10, 10), vec2(16), 0));
		this.name = name;
		this.color = ["red", "blue", "green", "yellow"].indexOf(name);
	}
	update() {
		super.update();
		let step = ((time * 6) % 8) | 0;
		this.tileInfo = tile(
			vec2(this.color, step < 4 ? 0 : step - 4),
			vec2(8, 10),
			2,
		);
	}
}

class Player extends GameObject {
	constructor(...args) {
		super(...args);
		this.drawSize = vec2(1);
		this.maskColor = MASKS[0];
		this.inGas = "none";
		this.health = 100;
		this.setCollision();
	}

	update() {
		super.update();

		const moveInput = keyDirection().clampLength(1);
		this.velocity = this.velocity.add(moveInput.scale(0.05));
		this.mirror = this.velocity.x < 0;
		cameraPos = this.pos.add(vec2(0, 2)).add(this.velocity.multiply(vec2(-1)));

		this.state = moveInput.length() > 0 ? this.walk : this.idle;
		this.state();

		for (const lever of level.levers) {
			if (keyWasPressed("Space") && this.pos.distance(lever.pos) < 1)
				lever.toggle();
		}

		for (const mask of level.masks) {
			if (keyWasPressed("Space") && this.pos.distance(mask.pos) < 1) {
				mask.destroy();
				level.masks = level.masks.filter((m) => m !== mask);
				this.maskColor = this.maskColor === mask.name ? "none" : mask.name;
			}
		}
	}

	die() {
		this.pos = vec2(0, -14)// TODO level.startPos get changed to the current position somehow;
		this.health = 100;
	}

	setAnimation(animState) {
		const animations = {
			idle: { rowOffset: 0, frames: 2, speed: 4 },
			walk: { rowOffset: 1, frames: 4, speed: 6 },
		};
		const anim = animations[animState];
		this.tileInfo = tile(
			vec2(0, MASKS.indexOf(this.maskColor) * 2 + anim.rowOffset),
			vec2(19, 21),
			1,
		).frame(((time * anim.speed) % anim.frames) | 0);
	}

	idle = () => this.setAnimation("idle");
	walk = () => {
		if ((time * 6) % 2 === 0) sfx.walk.play(this.pos, 0.2);
		this.setAnimation("walk");
	};

	render() {
		const offset = this.pos
			.subtract(cameraPos)
			.multiply(vec2(0.05))
			.add(vec2(0, 0.25));
		if (this.pos.y > -14.8 && this.inGas == "none")
			drawTile(
				this.pos.add(offset),
				vec2(1),
				tile(vec2(), vec2(19, 21), 1).frame(2),
			);
		super.render();
	}
}
